# Deviations from the pre-registered analysis plan

Every change made after the plan was frozen is listed here, with its reason and date.

| Date | Section | Change | Reason |
|---|---|---|---|
| 2026-11-22 | Step D (simulation) | Predictors defined by an AUROC *increment* over morphology, and the morphology predictor anchored on the observed Gardner gain (E1), instead of absolute AUROC targets | In a pipeline check, absolute AUROC targets mapped to selection gains about twice the observed one at the model's own AUROC: the AUROC of a pooled population depends on patient-level spread, which the simulation cannot reproduce exactly. Anchoring on E1 makes the comparison internally consistent. |
| 2026-11-22 | Step F | Step F used as a model-free consistency check of the value of choice, not to narrow the embryo-level SD | With the morphology predictor fixed, the implied slope barely changes with the embryo-level SD; the SD is bounded only by its ability to reproduce E1. |
| 2026-11-22 | Step E | 6 retained embryologists (not 7) | Kromp et al. retain Annotator 0, 1, 2, 5, 7, 8 (+ the Gardner expert) after consensus filtering. |
| 2026-11-22 | Step B | 709 transfers (not 710) | One transferred image (846_01) has no expert grade. |
| 2026-11-22 | Step B | Imputation moved inside each cross-fitting fold (fitted on training patients; outcome used for training patients only), and ridge penalty chosen by nested CV in each training fold | Review of possible data leakage: imputing once on all patients with the outcome, and tuning the penalty on all data, let test-fold information reach test predictions (small effect, removed). Bootstrap replicates reuse the median nested penalty for speed. |
| 2026-11-22 | Step B | Fold-wise imputation by proper stochastic regression (one posterior draw of coefficients and residual SD) instead of chained equations | 10x faster, needed to run the imputation inside every fold of every bootstrap replicate; same variables and order. Chained equations kept for step F (inference). |
| 2026-11-22 | Step F | Hidden-selection test: leak-free cross-fitting re-run in each bootstrap replicate (was: stored predictions resampled); failed step-F replicates now counted | CI must include model uncertainty; transparency of the bootstrap. |
| 2026-11-22 | Step C | Negative control added: estimands recomputed with outcomes permuted across transfers (noise floor, incl. winner's curse) | A synthetic check showed that choosing the maximum of noisy predictions creates an apparent gain; E3 must be read against this floor. |
| 2026-11-22 | Steps B, C | Clinical pregnancy with heart activity (HA) added as key secondary outcome (discrimination by group, model-free check), primary outcome unchanged (live birth) | Comparability with Illingworth et al. (primary endpoint HA); more events. |
| 2026-11-22 | Step B | Discrimination reported separately for patients with and without a choice | The overall AUROC hides the absence of discrimination among chosen embryos. |
| 2026-11-22 | Step G | Strategies valued by the image model's own probabilities not reported; within-choice-set AUROC is the decisive quantity | Self-valuation is inflated by winner's curse (a pure-noise image model showed +5.8 points). |
