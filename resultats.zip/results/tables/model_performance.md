| metric | value |
|---|---|
| Cross-validated AUROC | 0.5524654294032023 |
| Cross-validated calibration intercept | -0.00013990332530863792 |
| Cross-validated calibration slope | 0.8915923113724495 |
| Brier score | 0.21604454272940807 |
| Apparent AUROC | 0.6097798398835517 |
| Optimism-corrected AUROC | 0.569539334630799 |
| Optimism-corrected calibration slope | 1.1311185098217922 |
| Transfers / live births | 709 / 229 |
| Ridge C (median of nested folds) | 0.019306977288832496 |
| Cross-validated AUROC, day 5, choice (>=2 blastocysts) | 0.489 [0.429, 0.549] |
| Cross-validated AUROC, day 5, no choice (1 blastocyst) | 0.634 [0.559, 0.709] |
| HA outcome: cross-validated AUROC | 0.5776938465783663 |
| HA outcome: cross-validated AUROC, day 5, choice (>=2 blastocysts) | 0.5298209385104475 |
| HA outcome: cross-validated AUROC, day 5, no choice (1 blastocyst) | 0.6341891595347816 |
